# Collage Motion / local demo

Arrange imported images into an animated collage, adjust per-cell flash timing,
preview the composition and export video. This is the recovered original tool.
It starts with an empty asset list; bring your own images.

## Open in Chrome

1. Extract this ZIP into a folder.
2. Open a terminal in that folder. With Python 3 installed, run:

   python -m http.server 8766 --bind 127.0.0.1

   On Windows you can use `py -m http.server 8766 --bind 127.0.0.1`.
3. Open http://127.0.0.1:8766/per-cell-flash-studio.html in Chrome.
4. Import images, adjust the composition/timing, preview, then export.
5. Press Ctrl+C in the terminal to stop the local server.

If port 8766 is busy, use a different port in both the command and URL.
Keep the files together. Use the local server instead of double-clicking the
HTML so browser module loading works. No account or package installation is
required; Python and Chrome must already be available.

## Checked scope

The recovered tool previously exported a playable 720p, five-second H.264
video with synthetic images. This package preserves that application and its
local runtime dependencies. 4K and long exports have not been verified.

Personal media, conversation backups and the private tools portal are excluded.
Third-party dependency licenses are included in licenses/.
