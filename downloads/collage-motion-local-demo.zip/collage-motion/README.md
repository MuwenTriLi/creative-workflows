# Collage Motion

Hosted app: https://muwentrili.github.io/creative-workflows/collage-motion/

For local use, extract and run `python -m http.server 8766 --bind 127.0.0.1`, then open http://127.0.0.1:8766/ in Chrome or Edge. No Python packages required.

Import media, compose and scrub the timeline, then Review & export. Media stays in the tab; reloading clears it. Exports are silent video. A five-second 720p H.264 export was checked; 4K, long clips and large mixed-video projects need broader testing.
