# Collage Motion

Open the hosted app: https://muwentrili.github.io/creative-workflows/collage-motion/

For local use, extract this folder and run `python -m http.server 8766 --bind 127.0.0.1`, then open http://127.0.0.1:8766/ in Chrome. No Python packages are needed.

The editor starts empty and paused. Import your own images or clips with Choose assets. Includes local dependencies and license notices. The export path was tested with temporary images at 720p for five seconds; 4K and long exports are not verified. Media stays in the browser tab and is cleared on reload.
