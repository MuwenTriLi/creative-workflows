# Collage Motion

Open the hosted app: https://muwentrili.github.io/creative-workflows/collage-motion/

For local use, extract this folder and run `python -m http.server 8766 --bind 127.0.0.1`, then open http://127.0.0.1:8766/ in Chrome. No Python packages are needed.

Includes the current editor, built-in procedural samples and local dependencies with license notices. Tested: sample loading, grid adjustment and a five-second 720p H.264 export (150 frames at 30 fps). 4K and long exports are not verified. Your media stays in the browser tab and is cleared on reload.
